export default function Sobre() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold">Sobre o Escritório</h1>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-10 space-y-6">
        <section>
          <h2 className="text-2xl font-semibold mb-4">Nossa História</h2>
          <p>
            O escritório Micael Melo Advocacia nasceu do compromisso com a ética, excelência e responsabilidade na prestação
            de serviços jurídicos. Fundado pelo Dr. Micael Melo, advogado com sólida experiência nas áreas Previdenciária,
            Imobiliária e Empresarial, o escritório tem como missão proporcionar atendimento de qualidade e soluções eficazes.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Nossa Missão</h2>
          <p>
            Oferecer assessoria jurídica humanizada, transparente e eficiente, sempre focando na solução de conflitos e na
            proteção dos interesses de nossos clientes.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold mb-4">Nossos Valores</h2>
          <ul className="list-disc list-inside">
            <li>Ética profissional</li>
            <li>Transparência e confiança</li>
            <li>Eficiência nos resultados</li>
            <li>Atendimento personalizado</li>
            <li>Respeito aos direitos individuais</li>
          </ul>
        </section>
      </main>

      <footer className="bg-gray-100 text-center py-4">
        <p>© 2025 Micael Melo Advocacia – Todos os direitos reservados.</p>
      </footer>
    </div>
  )
}
