export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Micael Melo Advocacia</h1>
          <nav className="space-x-4">
            <a href="#sobre" className="hover:underline">Escritório</a>
            <a href="#areas" className="hover:underline">Áreas de Atuação</a>
            <a href="#contato" className="hover:underline">Contato</a>
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-10">
        <section className="text-center py-20">
          <h2 className="text-4xl font-bold mb-4">Excelência jurídica com confiança e compromisso.</h2>
          <p className="text-lg mb-6">Especialistas em Direito Previdenciário, Imobiliário e Empresarial.</p>
          <a href="#contato" className="px-6 py-3 bg-blue-900 text-white rounded hover:bg-blue-800">Agende sua consulta</a>
        </section>

        <section id="sobre" className="py-10">
          <h3 className="text-2xl font-semibold mb-4">Sobre o Escritório</h3>
          <p>
            Fundado com o propósito de oferecer soluções jurídicas eficazes e éticas, o Micael Melo Advocacia atua com
            excelência nas áreas Previdenciária, Imobiliária e Empresarial. Com atendimento humanizado, comprometemo-nos
            com a defesa dos interesses de nossos clientes, prezando pela transparência, agilidade e confiança.
          </p>
        </section>

        <section id="areas" className="py-10">
          <h3 className="text-2xl font-semibold mb-6">Áreas de Atuação</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-6 shadow rounded">
              <h4 className="font-bold mb-2">Direito Previdenciário</h4>
              <p>Aposentadorias, BPC, pensões e revisões.</p>
            </div>
            <div className="bg-white p-6 shadow rounded">
              <h4 className="font-bold mb-2">Direito Imobiliário</h4>
              <p>Distratos, inventário, usucapião e regularizações.</p>
            </div>
            <div className="bg-white p-6 shadow rounded">
              <h4 className="font-bold mb-2">Direito Empresarial</h4>
              <p>Consultoria, contratos, proteção jurídica.</p>
            </div>
          </div>
        </section>

        <section id="contato" className="py-10">
          <h3 className="text-2xl font-semibold mb-4">Contato</h3>
          <p>Endereço: Rua Doutor José Nogueira, 78, Aeroporto, Mossoró - RN</p>
          <p>Telefone/WhatsApp: (84) 3190-0809</p>
          <p>Email: contato@micaelmelo.com.br</p>
        </section>
      </main>

      <footer className="bg-gray-100 text-center py-4">
        <p>© 2025 Micael Melo Advocacia – Todos os direitos reservados.</p>
      </footer>
    </div>
  )
}
