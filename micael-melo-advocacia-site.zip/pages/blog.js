export default function Blog() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold">Blog Jurídico</h1>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-10 space-y-10">
        <section>
          <h2 className="text-2xl font-semibold mb-4">Últimos Artigos</h2>
          <div className="space-y-8">
            <article className="border-b pb-6">
              <h3 className="text-xl font-semibold">5 Dicas para Evitar Problemas em Contratos Imobiliários</h3>
              <p className="text-sm text-gray-600 mb-2">Publicado em 10 de maio de 2025</p>
              <p>
                Conheça orientações essenciais para garantir segurança jurídica na compra e venda de imóveis.
              </p>
            </article>

            <article className="border-b pb-6">
              <h3 className="text-xl font-semibold">Aposentadoria Especial: Quem tem direito?</h3>
              <p className="text-sm text-gray-600 mb-2">Publicado em 5 de maio de 2025</p>
              <p>
                Entenda os critérios para solicitar a aposentadoria especial e como aumentar suas chances de concessão.
              </p>
            </article>

            <article className="border-b pb-6">
              <h3 className="text-xl font-semibold">Como regularizar imóveis herdados?</h3>
              <p className="text-sm text-gray-600 mb-2">Publicado em 30 de abril de 2025</p>
              <p>
                Saiba como funciona o inventário e os passos legais para transferir a propriedade do imóvel.
              </p>
            </article>
          </div>
        </section>
      </main>

      <footer className="bg-gray-100 text-center py-4">
        <p>© 2025 Micael Melo Advocacia – Todos os direitos reservados.</p>
      </footer>
    </div>
  )
}
